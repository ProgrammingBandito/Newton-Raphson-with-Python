#################################################
#AUTHOR: DOMINIC HOO
#DATE: 5/4/2018
#Python version 3.6.4
#################################################
#Space Shuttle Functions
#################################################

from math import sin, cos

def angle_function(x, t_b, t_s, w_b, w_s, len_a, len_b, height, g): #Function
	"""
	Inputs:		inital value, combined SRB and External Tank thrust,Orbiter Thrust, combined weight of SRB and External Tank, length a, lenght b, height, gravity
	Operation:	calculates the function, f(theta).
	Output:		angle_out is the angle for calculation by nr_method.
	"""
	angle_out = t_b*len_a + g*w_s*height + t_s*height*sin(x) - t_s*len_b*cos(x) - g*w_b*len_a
	return angle_out

def angle_derived(x, t_b, t_s, len_a, len_b, height): #Dervied Function
	"""
	Inputs:		Same as above except w_b and w_s are not present.
	Operation:	Calculates the derived function, f'(theta).
	Output:		angle_derived_out is the derived angle for calculation by nr_method.
	"""
	angle_derived_out = t_s*height*cos(x) + t_s*len_b*sin(x)
	return angle_derived_out

def nr_method(x, t_b, t_s, w_b, w_s, len_a, len_b, height, g):
	
	"""
	Inputs:		Same inputs as angle_function
	Operation:	Calculates the Newton-Raphson method for an iteration of 1000 times.
	Exception:	Checks if angle_derived equals zero to prevent a Zero Division Error.
	Output:		x is the appropriate nozzle angle for ensuring a stable flight path. 
	"""
	if angle_derived(x, t_b, t_s, len_a, len_b, height) == 0:
		raise Exception("ERROR: Zero Division, start again.")

	for i in range(1,1000):
		x = x - angle_function(x, t_b, t_s, w_b, w_s, len_a, len_b, height, g)/angle_derived(x, t_b, t_s, len_a, len_b, height)
	return x

