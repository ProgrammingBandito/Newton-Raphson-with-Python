#################################################
#AUTHOR: DOMINIC HOO
#DATE: 5/4/2018
#Python version 3.6.4
#################################################

from van_der_waals_functions import nr_method

#*****************************************************
initial_value = 20 # Please change initial value here.
#*****************************************************

pressure_values = [1,1.5,2,2.5,3,5,10,15,25,50]
vol_values = []

#*****************************************************
if initial_value > 15 and initial_value < 26:

    for press_atm in pressure_values:
        volume = nr_method( initial_value, press_atm)
        vol_values.append(volume)

    print('The volume values are: ', vol_values)

else:
    print("Values outisde of stated parameters, please start again.")

"""
I understand this is not exactly a help file. 
However,these  doc-strings are the equivalent in Python.

pressure_values:    Do not change this as it's values are set specificly for this assignment.
vol_values:         Stores calculated value

Operation:          This program will only calculate for an initial value between 15 and 26. 
                    It will calculate the volume for each value in pressure_values and output vol_values results for graphing purposes.
"""