#################################################
#AUTHOR: DOMINIC HOO
#DATE: 5/4/2018
#Python version 3.6.4
#################################################
#Part 2
#################################################

from SpaceFunctions import angle_function,angle_derived,nr_method

#*******************
x = 6 #initial value
#*******************


t_b = 23.6e6
t_s = 5.03e6
w_b = 1607060.95
w_s = 104326.245 
len_a = 0.5202
len_b = 8.5344 - len_a
height = 11.5824
g = 9.81

if x > 5 and x < 8:
    angle = nr_method(x, t_b, t_s, w_b, w_s, len_a, len_b, height, g)

    print("The angle for nozzle at 25 percent is: ", angle)
    
else:
    print("Values entered outside of stated parameters. Please try again.")


"""
Same documentation as Shuttle_Engine.py but with variables w_b, w_s and len_a changed.

"""