#################################################
#AUTHOR: DOMINIC HOO
#DATE: 5/4/2018
#Python version 3.6.4
#################################################
#Van Der Waals Functions
#################################################

def vol_function(v, press_atm): #Function
	"""
	Inputs: 	volume, pressure
	Operation:	calculates the function, f(v).
	Output:		ans_one is the output volume, this is used by the nr_method function.
	"""
	ans_one = (v**3)*(press_atm)-(v**2)*(0.04267*press_atm + 24.042701)+(v*(3.640))-0.1553188
	return ans_one

def vol_derived(v, press_atm): #Function Dervied
	"""
	Inputs:		volume, pressure
	Operation:	calculates the function, f'(v).
	Output:		ans_two is the derived output volume, also used by nr_method.
	"""
	ans_two = 3*(press_atm)*(v**2)-((0.08534*press_atm + 48.085402)*v)+3.640
	return ans_two

def nr_method(vol, press_atm):
	"""
	Input:		volume, pressure. Both of these values come from the function call in vanderwaals.py
	Operation:	The Newton-Raphson Method is executed here. It performs the Newton-Raphson Method for 1000 iterations.
	Exception:	If vol_derived is 0, the program will halt to prevent a  ZeroDivision Error.
	Output:		vol is the final volume for graphing in vanderwaals.py.
	"""
	
	if vol_derived(vol, press_atm) == 0:
		raise Exception("ERROR: Zero Division, start again.")

	for i in range(1,1000): #this is the value of precision
		vol = vol - vol_function( vol, press_atm)/vol_derived( vol, press_atm)
	return vol