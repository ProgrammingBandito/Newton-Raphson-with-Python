#################################################
#AUTHOR: DOMINIC H00
#DATE: 5/4/2018
#Python version 3.6.4
#################################################
#Part 1
#################################################

from SpaceFunctions import angle_function,angle_derived,nr_method

#*******************************
x = 6 #Change Initial value here
#*******************************


t_b = 23.6e6
t_s = 5.03e6
w_b = 1921397.469
w_s = 104326.245 
len_a = 0.439674
len_b = 8.5344 -len_a
height = 11.5824
g = 9.81

if x > 5 and x < 8:

	angle = nr_method(x, t_b, t_s, w_b, w_s, len_a, len_b, height, g)
	print("The angle for nozzle at lift off is: " , angle)

else:
	print("Values entered outside of stated parameters. Please try again.")


"""
This is the doc-string for Problem 3.9

Variables: t_b, t_s...etc. follow convetion from Assignment1.pdf
		   however, len_a and len_b denote length a and b.

Operation:	Only values between 5 and 8 are allowed for x as this ensures an acceptable result.
			Calls the nr_method function (from SpaceFunctions.py) once.
"""
